/*
 * images.h
 *
 *  Created on: 2024��12��27��
 *      Author: 17807
 */

#ifndef CODE_IMAGES_H_
#define CODE_IMAGES_H_

#include "zf_common_headfile.h"

extern uint8  mt9v03x_image_Bandw[MT9V03X_H][MT9V03X_W];
extern uint8 bai_lie;
extern uint8 distance;
extern uint8 bai_num[MT9V03X_W];
extern uint8 mid_line_1;

extern uint8 point_up;
extern uint8 point_down;
extern int baidian;
extern int baidian_1;
extern uint8 piancha;
void juli(void);
void baise(void);
void Pixle_Filter(void);
void draw_points(uint8 x,uint8 y,uint16 color);
void Draw_Line(void);
void set_image_two_values(uint8 value);

#endif /* CODE_IMAGES_H_ */
