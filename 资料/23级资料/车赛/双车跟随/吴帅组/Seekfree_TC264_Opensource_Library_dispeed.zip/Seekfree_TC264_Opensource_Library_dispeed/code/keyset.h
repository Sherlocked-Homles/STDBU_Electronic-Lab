/*
 * key.h
 *
 *  Created on: 2024��4��11��
 *      Author: ��
 */

#ifndef CODE_KEYSET_H_
#define CODE_KEYSET_H_


#include "zf_common_headfile.h"

#define key1 P20_6
#define key2 P20_7
#define key3 P11_2
#define key4 P11_3

extern uint8 fache;

void key1_init(void);//��CPU0��
void key1_set(void);//cpu0mainѭ��



#endif /* CODE_KEYSET_H_ */
