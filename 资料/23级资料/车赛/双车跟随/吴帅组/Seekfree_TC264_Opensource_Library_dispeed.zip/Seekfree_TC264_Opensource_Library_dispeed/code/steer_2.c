/*
 * steer_2.c
 *
 *  Created on: 2024??4??26??
 *      Author: 17807
 */

#include "steer_2.h"
#include "zf_common_headfile.h"

#define STEER_RIGHT  808-77  //????????,-
#define STEER_MID    808  //???????
#define STEER_LEFT   808+77
//????????,+

#define LEFT_MAX     (STEER_LEFT- STEER_MID)//+
#define RIGHT_MAX    (STEER_RIGHT-STEER_MID)//-

float  P_duoji1=2.8;//250?? 4.4??300?? 2.8//2.8
float  D_duoji1=20.1;//1.632  250??20.1??23.2//23.2

//float  P_duoji2=0.4;//250?? 4.4
//float  D_duoji2=20;//1.632  250??20.1

//????????
int PD_Camera(float expect_val, float err, float  P_duoji,float  D_duoji)//???PD????
{
   float  u;
 //????????????????????????????.
   volatile static float error_current,error_last;
   float ek,ek1;
   error_current=err-expect_val;
   ek=error_current;
   ek1=error_current-error_last;
   u=P_duoji*ek+D_duoji*ek1;
   error_last=error_current;

   if(u>=LEFT_MAX)//???????
       u=LEFT_MAX;
   else if(u<=RIGHT_MAX)//???????
       u=RIGHT_MAX;
   return (int)u;
}


void Steer(int angle)
{
    if(angle>=LEFT_MAX)//???????
       angle=LEFT_MAX;
   else if(angle<=RIGHT_MAX)
        angle=RIGHT_MAX;
    pwm_set_duty(ATOM1_CH1_P33_9, STEER_MID+angle);//???????
}

