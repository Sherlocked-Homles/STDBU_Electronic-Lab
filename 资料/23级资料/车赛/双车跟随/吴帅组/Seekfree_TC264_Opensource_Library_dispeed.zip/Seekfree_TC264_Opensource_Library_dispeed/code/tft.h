/*
 * tft.h
 *
 *  Created on: 2024��4��1��
 *      Author: 17807
 */

#ifndef CODE_TFT_H_
#define CODE_TFT_H_

#include "zf_common_headfile.h"
void tft_control(void);
extern uint8 i_saikuan;

#endif /* CODE_TFT_H_ */
