/*
 * steer_2.h
 *
 *  Created on: 2024��4��26��
 *      Author: 17807
 */

#ifndef CODE_STEER_2_H_
#define CODE_STEER_2_H_

#include "zf_common_headfile.h"

extern float P_duoji1;//��ֱ��
extern float  D_duoji1;

extern float P_duoji2;//ֱ��
extern float  D_duoji2;

int PD_Camera(float expect_val,float err, float  P_duoji,float  D_duoji);

void Steer(int angle);


#endif /* CODE_STEER_2_H_ */
