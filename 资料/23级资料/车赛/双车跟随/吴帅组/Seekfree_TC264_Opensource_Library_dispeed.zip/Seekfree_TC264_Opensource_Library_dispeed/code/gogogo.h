/*
 * gogogo.h
 *
 *  Created on: 2024��4��10��
 *      Author: 17807
 */

#ifndef CODE_GOGOGO_H_
#define CODE_GOGOGO_H_

#include "zf_common_headfile.h"


void run_1(void);

#endif /* CODE_GOGOGO_H_ */
