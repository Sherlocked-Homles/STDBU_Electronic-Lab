/*
 * motor.h
 *
 *  Created on: 2024��4��15��
 *      Author: 17807
 */

#ifndef CODE_MOTOR_H_
#define CODE_MOTOR_H_

#include "zf_common_headfile.h"

//������
#define ENCODER_L_CH1   TIM2_ENCODER_CH1_P33_7//
#define ENCODER_L_CH2   TIM2_ENCODER_CH2_P33_6
#define ENCODER_L_TIM   TIM2_ENCODER

#define ENCODER_R_CH1   TIM4_ENCODER_CH1_P02_8
#define ENCODER_R_CH2   TIM4_ENCODER_CH2_P00_9
#define ENCODER_R_TIM   TIM4_ENCODER

extern int Speed_Left_Real;
extern int Speed_Right_Real;

extern int Speed_Left_Set;
extern int Speed_Right_Set;
extern int baidian_s;
extern unsigned char clock_flag;
extern int delay;

extern int temp;

extern float P_L;
extern float I_L;
extern double kp;
extern double ki;
void Motor_banma_LEFT(int pwm_L);
void Motor_banma_RIGHT(int pwm_L);

void Motor_LEFT(int pwm_R);
void Motor_Right(int pwm_R);
int PID_L(int set_speed ,int speed);
int PID_R(int set_speed ,int speed);
void Velocity_Control(int speed_left_real,int speed_right_real);
void motor_init(void);

#endif /* CODE_MOTOR_H_ */
