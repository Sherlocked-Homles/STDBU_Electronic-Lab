/*
 * kaihuan.h
 *
 *  Created on: 2024��4��11��
 *      Author: 17807
 */

#ifndef CODE_KAIHUAN_H_
#define CODE_KAIHUAN_H_

#include "zf_common_headfile.h"

extern uint16 straight_speed;
extern uint16 wan_speed;

void kaihuan (void);

#endif /* CODE_KAIHUAN_H_ */
