/*
 * control.c
 *
 *  Created on: 2024年4月1日
 *      Author: 17807
 */
#include "control.h"
#include "zf_common_headfile.h"

/*
#define STEER_RIGHT  744  //舵机右打死,-
#define STEER_MID    821  //舵机归中
#define STEER_LEFT   898  //舵机左打死,+
*/

uint16 dianji_value = 1900;//速度  //好像没用到？
uint16 duoji_value = 808;//在赛道上看直走是多少。再改
uint16 duoji_temp = 808;



void control_init(void)
{
    gpio_init(P02_4, GPO, GPIO_HIGH, GPO_PUSH_PULL);         //DIR_R1                  // GPIO 初始化为输出 默认上拉输出高
    pwm_init(ATOM0_CH5_P02_5, 17000, 0);                 //PWM_R1                    // PWM 通道初始化频率 17KHz 占空比初始为 0
    gpio_init(P02_6, GPO, GPIO_HIGH, GPO_PUSH_PULL);         //DIR_L1                  // GPIO 初始化为输出 默认上拉输出高
    pwm_init(ATOM0_CH7_P02_7, 17000, 0);                 //PWM_L1                     // PWM 通道初始化频率 17KHz 占空比初始为 0

//    gpio_init(P21_2, GPO, GPIO_HIGH, GPO_PUSH_PULL);        //同上，2                   // GPIO 初始化为输出 默认上拉输出高
//    pwm_init(ATOM0_CH1_P21_3, 17000, 0);                                                 // PWM 通道初始化频率 17KHz 占空比初始为 0
//    gpio_init(P21_4, GPO, GPIO_HIGH, GPO_PUSH_PULL);                           // GPIO 初始化为输出 默认上拉输出高
//    pwm_init(ATOM0_CH3_P21_5, 17000, 0);                                                 // PWM 通道初始化频率 17KHz 占空比初始为 0
    //舵机的PWM
    pwm_init(ATOM1_CH1_P33_9, 50, 808);//只修改最后的占空比
}
/*---------------------------------------------------------------
 【函    数】duoji_duty_update(uint8 mid,float kp)
 【功    能】舵机占空比更新函数
 【参    数】无
 【返 回 值】无
 【注意事项】
 ----------------------------------------------------------------*/
void duoji_duty_update(uint8 mid,float kp)
{
    float temp;
    if(mid < MID_W)
    {
        temp = kp*(MID_W - mid);
        pwm_set_duty(ATOM1_CH1_P33_9 , duoji_value + temp);
        duoji_temp=duoji_value + temp;
    }
    else
    {
        temp = kp*(mid - MID_W);
        pwm_set_duty(ATOM1_CH1_P33_9 , duoji_value - temp);
        duoji_temp=duoji_value - temp;
    }
}

