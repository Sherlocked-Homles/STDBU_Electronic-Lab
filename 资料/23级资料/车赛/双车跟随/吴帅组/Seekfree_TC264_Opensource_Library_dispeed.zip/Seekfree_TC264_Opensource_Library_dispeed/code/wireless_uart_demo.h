#ifndef CPU0_MAIN_H
#define CPU0_MAIN_H
#include "zf_common_headfile.h"
/******************************************************************************/
/*----------------------------------Includes----------------------------------*/
/******************************************************************************/


#include "Cpu/Std/Ifx_Types.h"
/******************************************************************************/
/*-----------------------------------Macros-----------------------------------*/
/******************************************************************************/

/******************************************************************************/
/*------------------------------Type Definitions------------------------------*/
/******************************************************************************/
void wireless_init(void);
void wireless_shuju(void);
void wireless_send_number();

#define LED2                    (P20_8)
#define LED1                    (P20_9)
extern int data_len;
typedef struct
{
    float32 sysFreq;                /**< \brief Actual SPB frequency */
    float32 cpuFreq;                /**< \brief Actual CPU frequency */
    float32 pllFreq;                /**< \brief Actual PLL frequency */
    float32 stmFreq;                /**< \brief Actual STM frequency */
} AppInfo;

/** \brief Application information */
typedef struct
{
    AppInfo info;                               /**< \brief Info object */
} App_Cpu0;

/******************************************************************************/
/*------------------------------Global variables------------------------------*/
/******************************************************************************/

IFX_EXTERN App_Cpu0 g_AppCpu0;

#endif
